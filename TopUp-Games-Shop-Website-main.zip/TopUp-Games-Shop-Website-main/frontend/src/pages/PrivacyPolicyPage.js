
const PrivacyPolicyPage = () => {
    return(
        <div></div>
    )
}

export default PrivacyPolicyPage;