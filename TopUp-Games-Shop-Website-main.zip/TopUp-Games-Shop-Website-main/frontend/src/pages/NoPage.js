
const NoPage = () => {
    return(
        <div></div>
    )
}

export default NoPage;