
const TermsConditionPage = () => {
    return(
        <div></div>
    )
}

export default TermsConditionPage;